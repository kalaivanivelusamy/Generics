//: Playground - noun: a place where people can play


var str = "Hello, playground"
 func addition<T:Numeric>(a:T,b:T) -> T
{
    return a+b
}

print(addition(a: 3, b: 4))

print(addition(a: 3.0, b: 4.25))

class Book
{
    var title : String
    var author : String
    
    init(name:String,by:String)
    {
        self.title = name
        self.author = by
    }
}

class Shoe
{
    var brand : String
    var size : Int
    
    init(name:String,size:Int)
    {
        self.brand = name
        self.size = size
    }
}

//Using Generics in Protocol
protocol storage
{
    associatedtype Item
    func addItem(item: Item)
    func retrieveItem(at: Int) -> Item
    
}

//The following class uses the generic protocol

class Trunk<Item>:storage
{
    var items = [Item]()
    
    func addItem(item: Item) {
        items.append(item)
    }
    
    func retrieveItem(at: Int) -> Item {
        return items[at]
    }
    
}

//Class truck can take book or shoe class also since its of Generic type
let bookTrunk = Trunk<Book>()
bookTrunk.addItem(item: Book(name: "Thousand splendid suns", by: "khaled hossini"))
bookTrunk.addItem(item: Book(name: "Thousand splendid sun", by: "khaled hossini"))

print(bookTrunk.retrieveItem(at: 1).title)


let shoeTrunk = Trunk<Shoe>()
shoeTrunk.addItem(item: Shoe(name: "Reebok", size: 12))
shoeTrunk.addItem(item: Shoe(name: "Puma", size: 13))

print(shoeTrunk.retrieveItem(at: 1).brand)


